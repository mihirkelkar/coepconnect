<html>
<head>
	<title>COEP Connect</title>
</head>
<body>
	<?php
	
	//Database Connection
	$db = mysql_connect("localhost", "admin", "admin123") or die(mysql_error());
	mysql_select_db("cc",$db) or die(mysql_error());
	//Username Check
	if(empty($_POST['uname'])) {
      	$errorMessage .= "<li>No Username Entered</li>";
   		header( 'Location: http://localhost/db/lhome.php' ) ;
   }
   	if(empty($_POST['password'])) {
      	$errorMessage .= "<li>No Password Entered</li>";
   		header( 'Location: http://localhost/db/lhome.php' ) ;
   }
	if(!empty($_POST['uname'])){
		$uname = $_POST['uname'];
	}
	if(!empty($_POST['password'])){
		$password = $_POST['password'];   
	}
	$q = "SELECT * FROM cc_users WHERE uname = '$uname' AND password = '$password'";
	
	$ucheck = mysql_query($q);
	$num = mysql_num_rows($ucheck);
	if($num==0)
	{
		echo "Bad";
	}
	else{
		echo "good";
	}
	
	?>
</body>
</html>