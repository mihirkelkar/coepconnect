<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>COEP Connect Register</title>
</head>

<body>
	<?php
    //Database Connection
	$flag = 0;
	echo $flag;
	$db = mysql_connect("localhost", "admin", "admin123") or die(mysql_error());
	mysql_select_db("cc",$db) or die(mysql_error());
	//Username Check
	if(empty($_POST['uname'])) {
      	$errorMessage = "<li>No Username Entered</li>";
		echo $errorMessage;
		$flag = 1;
   		//header( 'Location: http://localhost/db/lhome.html' ) ;
   }
   	else{
		$uname = $_POST['uname'];
	}   	
   	if(empty($_POST['password'])) {
     	 $flag = 1;
		 $errorMessage = "<li>No Password Entered</li>";
		 echo $errorMessage;
		 $flag = 1;
	  	//header( 'Location: http://localhost/db/lhome.html' ) ;
   }
   	else{
		$password = $_POST['password'];
	}	
   	if(empty($_POST['email'])) {
     	 $flag = 1;
		 $errorMessage = "<li>No Email Entered</li>";
		 echo $errorMessage;
		 $flag = 1;
	  	//header( 'Location: http://localhost/db/lhome.html' ) ;
   }
   	else{
		$email = $_POST['email'];
	}	
   	if(empty($_POST['phno'])) {
     	 $flag = 1;
		 $errorMessage = "<li>No Phone Number Entered</li>";
		 echo $errorMessage;
		 $flag = 1;
	  	//header( 'Location: http://localhost/db/lhome.html' ) ;
   }
   	else{
		$phno = $_POST['phno'];
	}	
   	if(empty($_POST['usloc'])) {
     	$flag = 1;
		$errorMessage = "<li>No Location entered Entered</li>";
		echo $errorMessage;
		$flag = 1;
	  	//header( 'Location: http://localhost/db/lhome.html' ) ;
   }
   	else{
		$usloc = $_POST['usloc'];
	}
	$qr = mysql_query("SELECT uname FROM cc_users WHERE uname = '$uname'");
	$check = mysql_num_rows($qr);
	
	if(empty($check) and $flag == 0){
		
		echo $uname.' '.$password.' '.$email.' '.$phno.' '.$usloc;
		mysql_query("INSERT INTO cc_users (uname, password,email,phone,location ) VALUES ('$uname', '$password', '$email','$phno','$usloc')");
	}
	else{
		echo "Username Exists or Form Incomplete";
	}
	echo $flag;
	?>
    


</body>
</html>
