<html>
<link rel="stylesheet" type="text/css" media="screen" href="css/lhome.css">
<head>
	<title>COEP Connect Login</title>
	<link rel="stylesheet" type="text/css" media="screen" href="css/lhome.css">

</head>

<body>
	<a href = 'lhome1.html'><img src = 'Logo.png'></a>
    <br>
    <br>
   	<table border="0">
    <tr>
    <td>
    <div class="login">
    	<h1>Login</h1>
        <form method="post" action="scripts/login.php">
			Username: <input type="text" name="uname" /><br /><br>
			Password: <input type="password" name="password" /><br><br>
            <div class = 'button'>
             	<input type="submit"  value = "Login" />
			</div>
            
       	</form> 
     </div>
     </td>
     <td>

     <div class = "register">
     	<h1>Register</h1>
        <form method="post" action="scripts/register.php">
			Username: <input type="text" name="uname" /><br /><br>
			Password: <input type="password" name="password" /><br><br>
            Email Id: <input type = "text" name = "email" ><br><br>
            Location: <input type = "text" name = "email" ><br><br>
            Phone no: <input type = "text" name = "email" ><br><br>
            
            <div class = 'button'>
           	  <input type="submit"  value = "Register" />
			</div>
       	</form>
       </div>
		</td>
       </tr>
       </table>

</body>
</html>
