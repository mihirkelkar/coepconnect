<html>
	<link rel="stylesheet" type="text/css" media="screen" href="css/layout1.css">
	<link rel="stylesheet" type="text/css" media="screen" href="css/dock-example1.css">
	
    <style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
    <head>
<noscript>
		<style type="text/css">
			#dock { top: -32px; }
			a.dock-item { position: relative; float: left; margin-right: 10px; }
			.dock-item span { display: block; }
		</style>
</noscript>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="js/fisheye-iutil.min.js"></script>
<script type="text/javascript" src="js/dock-example1.js"></script>
<title>COEP Connect</title>
<LINK REL="SHORTCUT ICON" HREF="favicon.ico">
</head>

<body>

	<p><a href = "../db"><img src = "Logo.png" alt = "COEP Connect"/></a></p>
<div id="dock">
<div align="bottom" class="dock-container">
				<a class="dock-item" href="index.php"><img src="http://www.geekpedia.com/Pictures/Icons/leopard-home-button_128x128.png" alt="COEP Connect" /><span class="style1">COEP Connect</span></a> 
				<a class="dock-item" href="example2.html"><img src="images/dock/email.png" alt="contact" /><span class="style1">Example&nbsp;2</span></a> 
				<a class="dock-item" href="example3.html"><img src="images/dock/portfolio.png" alt="portfolio" /><span class="style1">Example&nbsp;3</span></a> 
			
	</div>
		<!-- end div .dock-container -->
</div>
</body>
</html>
